// ============================================================================
// Module Name  : ClkDiv
// Description  : Synthesizable Integer Clock Divider with 50% Duty Cycle
//                Supports Even and Odd division ratios (N >= 2).
// Inputs       : i_ref_clk   - Reference input clock (fin)
//                i_rst_n     - Active-low asynchronous reset
//                i_clk_en    - Clock divider enable
//                i_div_ratio - Division ratio N (8-bit unsigned integer)
// Outputs      : o_div_clk   - Divided clock output (fout = fin / N)
// ============================================================================

module ClkDiv (
    input  wire       i_ref_clk,
    input  wire       i_rst_n,
    input  wire       i_clk_en,
    input  wire [7:0] i_div_ratio,
    output wire       o_div_clk
);

    // ------------------------------------------------------------------------
    // Enable Logic & Corner Case Handling
    // Enable divider only if i_clk_en is HIGH AND i_div_ratio != 0 AND != 1
    // ------------------------------------------------------------------------
    wire clk_div_en;
    assign clk_div_en = i_clk_en && (i_div_ratio != 8'd0) && (i_div_ratio != 8'd1);

    // ------------------------------------------------------------------------
    // Internal Registers & Signals
    // ------------------------------------------------------------------------
    reg [7:0] pos_cnt;
    reg       p_clk;
    reg       n_clk;

    wire      is_odd;
    wire      divided_clk;

    // Check if division ratio is odd
    assign is_odd = i_div_ratio[0];

    // ------------------------------------------------------------------------
    // Posedge Counter & Posedge Clock Generator
    // ------------------------------------------------------------------------
    always @(posedge i_ref_clk or negedge i_rst_n) begin
        if (!i_rst_n) begin
            pos_cnt <= 8'd0;
            p_clk   <= 1'b0;
        end else if (clk_div_en) begin
            if (pos_cnt == (i_div_ratio - 8'd1)) begin
                pos_cnt <= 8'd0;
            end else begin
                pos_cnt <= pos_cnt + 8'd1;
            end

            // p_clk is HIGH for the first (i_div_ratio >> 1) cycles
            p_clk <= (pos_cnt < (i_div_ratio >> 1));
        end else begin
            pos_cnt <= 8'd0;
            p_clk   <= 1'b0;
        end
    end

    // ------------------------------------------------------------------------
    // Negedge Clock Generator (Provides 0.5 cycle phase shift for odd ratios)
    // ------------------------------------------------------------------------
    always @(negedge i_ref_clk or negedge i_rst_n) begin
        if (!i_rst_n) begin
            n_clk <= 1'b0;
        end else if (clk_div_en) begin
            n_clk <= p_clk;
        end else begin
            n_clk <= 1'b0;
        end
    end

    // ------------------------------------------------------------------------
    // Clock Output Multiplexing
    // - For Even ratios (is_odd == 0) : divided_clk = p_clk
    // - For Odd ratios  (is_odd == 1) : divided_clk = p_clk | n_clk
    // - If clk_div_en is LOW          : o_div_clk   = i_ref_clk (Bypass)
    // ------------------------------------------------------------------------
    assign divided_clk = is_odd ? (p_clk | n_clk) : p_clk;
    assign o_div_clk   = clk_div_en ? divided_clk : i_ref_clk;

endmodule
