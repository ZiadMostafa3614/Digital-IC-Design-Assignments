`timescale 1ns/1ps
// ============================================================
// UART RX Testbench
// TX Baud Rate : 115.2 KHz  -> TX bit period = 8680.555 ns
// RX CLK (Prescale=8)  : 921.6  KHz -> RX period = 1085.069 ns
// RX CLK (Prescale=16) : 1.843  MHz -> RX period =  542.535 ns
// RX CLK (Prescale=32) : 3.686  MHz -> RX period =  271.267 ns
// ============================================================
module UART_RX_tb;

    // DUT Ports
    reg        CLK;
    reg        RST;
    reg        PAR_TYP;
    reg        PAR_EN;
    reg  [5:0] Prescale;
    reg        RX_IN;
    wire [7:0] P_DATA;
    wire       data_valid;
    wire       Parity_Error;
    wire       Stop_Error;

    // DUT Instantiation
    UART_RX uut (
        .CLK(CLK),
        .RST(RST),
        .PAR_TYP(PAR_TYP),
        .PAR_EN(PAR_EN),
        .Prescale(Prescale),
        .RX_IN(RX_IN),
        .P_DATA(P_DATA),
        .data_valid(data_valid),
        .Parity_Error(Parity_Error),
        .Stop_Error(Stop_Error)
    );

    // --------------------------------------------------------
    // Clock: variable half-period driven by task parameter
    // Default period = 1085.069 ns (Prescale=8, 921.6 KHz)
    // --------------------------------------------------------
    real clk_half_period = 542.534; // half of 1085.069 ns
    always #(clk_half_period) CLK = ~CLK;

    integer err_count = 0;

    // Latches for capturing 1-cycle pulse of data_valid / error flags
    reg        dv_latch;
    reg  [7:0] pdata_latch;
    reg        par_err_latch;
    reg        stp_err_latch;
    reg        capture_en;    // Gate: only capture when frame is active

    always @(posedge CLK) begin
        if (capture_en) begin
            if (data_valid)   begin dv_latch <= 1'b1; pdata_latch <= P_DATA; end
            if (Parity_Error) par_err_latch <= 1'b1;
            if (Stop_Error)   stp_err_latch <= 1'b1;
        end
    end

    // --------------------------------------------------------
    // Reset Task
    // --------------------------------------------------------
    task do_reset;
    begin
        RST           = 1'b0;
        RX_IN         = 1'b1;
        capture_en    = 1'b0;
        dv_latch      = 1'b0;
        pdata_latch   = 8'h00;
        par_err_latch = 1'b0;
        stp_err_latch = 1'b0;
        repeat(10) @(posedge CLK);
        @(negedge CLK); RST = 1'b1;
        repeat(5) @(posedge CLK);
    end
    endtask

    // --------------------------------------------------------
    // Clear capture latches between frames
    // --------------------------------------------------------
    task clear_latches;
    begin
        @(negedge CLK);
        capture_en    = 1'b0;
        dv_latch      = 1'b0;
        pdata_latch   = 8'h00;
        par_err_latch = 1'b0;
        stp_err_latch = 1'b0;
    end
    endtask

    // --------------------------------------------------------
    // Send UART Frame Task
    // Each baud bit = prescale_val RX clock cycles
    // Frequencies match spec: TX=115.2KHz, RX=Prescale*115.2KHz
    // --------------------------------------------------------
    task send_uart_frame (
        input [7:0]    data,
        input          par_en,
        input          par_typ,
        input [5:0]    prescale_val,
        input          corrupt_par,
        input          corrupt_stp,
        input [8*60:1] tc_name
    );
    reg par_bit;
    integer i;
    begin
        $display("---------------------------------------------------------");
        $display("Running: %0s", tc_name);
        $display("  Prescale=%0d | RX_CLK=%.3f KHz | Data=0x%h | PAR_EN=%b | PAR_TYP=%b",
                  prescale_val,
                  prescale_val * 115.2,
                  data, par_en, par_typ);

        Prescale = prescale_val;
        PAR_EN   = par_en;
        PAR_TYP  = par_typ;

        // Set clock half-period for the new prescale
        // TX period = 8680.555 ns = prescale_val * RX_period
        clk_half_period = (8680.555 / prescale_val) / 2.0;

        clear_latches();

        // Compute parity bit
        if (par_typ == 1'b0) par_bit = ^data;    // Even parity
        else                 par_bit = ~(^data); // Odd parity
        if (corrupt_par)     par_bit = ~par_bit; // Inject parity error

        // Allow DUT to settle (wait for any residual error signals to deassert)
        repeat(5) @(posedge CLK);
        // Enable latch capture only AFTER error signals are gone
        @(negedge CLK); capture_en = 1'b1;

        // 1. START bit (logic 0) — 1 full baud = prescale_val RX clocks
        @(negedge CLK); #1; RX_IN = 1'b0;
        repeat(prescale_val) @(posedge CLK);

        // 2. DATA bits — b0 first (LSB first), 8 bits
        for (i = 0; i < 8; i = i + 1) begin
            @(negedge CLK); #1; RX_IN = data[i];
            repeat(prescale_val) @(posedge CLK);
        end

        // 3. PARITY bit (when enabled)
        if (par_en) begin
            @(negedge CLK); #1; RX_IN = par_bit;
            repeat(prescale_val) @(posedge CLK);
        end

        // 4. STOP bit (logic 1, or 0 to inject error)
        @(negedge CLK); #1;
        RX_IN = corrupt_stp ? 1'b0 : 1'b1;
        repeat(prescale_val) @(posedge CLK);

        // IDLE (line goes high)
        @(negedge CLK); #1; RX_IN = 1'b1;

        // Wait for FSM to evaluate CHK_ERR + register outputs
        repeat(prescale_val + 10) @(posedge CLK);

        // ---- Verify ----
        if (corrupt_par) begin
            if (!par_err_latch)
                begin $display("  -> ERROR: Expected Parity_Error=1, got 0!"); err_count=err_count+1; end
            else
                $display("  -> SUCCESS: Parity_Error = 1 (detected correctly)");
        end else if (corrupt_stp) begin
            if (!stp_err_latch)
                begin $display("  -> ERROR: Expected Stop_Error=1, got 0!"); err_count=err_count+1; end
            else
                $display("  -> SUCCESS: Stop_Error = 1 (detected correctly)");
        end else begin
            if (!dv_latch || pdata_latch !== data || par_err_latch || stp_err_latch)
                begin
                    $display("  -> ERROR: P_DATA=0x%h (Exp=0x%h), data_valid=%b, PAR_ERR=%b, STP_ERR=%b",
                              pdata_latch, data, dv_latch, par_err_latch, stp_err_latch);
                    err_count = err_count + 1;
                end
            else
                $display("  -> SUCCESS: P_DATA=0x%h, data_valid pulsed, no errors", pdata_latch);
        end

        clear_latches();
    end
    endtask

    // ============================================================
    // Main Stimulus
    // ============================================================
    initial begin
        CLK      = 0;
        RST      = 1'b1;
        RX_IN    = 1'b1;
        PAR_EN   = 1'b0;
        PAR_TYP  = 1'b0;
        Prescale = 6'd8;

        $display("=========================================================");
        $display("  UART RX Testbench — TX_CLK = 115.2 KHz");
        $display("=========================================================");

        do_reset();

        // =========================================================
        // SECTION 1: Oversampling Verification
        //   Req: UART_RX support oversampling by 8, 16, 32
        //   TX bit period = 8680.555 ns (at 115.2 KHz)
        // =========================================================
        $display("=========================================================");
        $display("  SECTION 1: Oversampling (Prescale = 8, 16, 32)");
        $display("=========================================================");

        // TC1: Prescale=8 -> RX_CLK = 921.6 KHz, Even Parity
        send_uart_frame(8'hA5, 1'b1, 1'b0, 6'd8, 1'b0, 1'b0,
            "TC1: Prescale=8  RX_CLK=921.6KHz  Even Parity  0xA5");

        // TC2: Prescale=16 -> RX_CLK = 1.843 MHz, Odd Parity
        send_uart_frame(8'hF3, 1'b1, 1'b1, 6'd16, 1'b0, 1'b0,
            "TC2: Prescale=16 RX_CLK=1.843MHz  Odd Parity   0xF3");

        // TC3: Prescale=32 -> RX_CLK = 3.686 MHz, No Parity
        send_uart_frame(8'h55, 1'b0, 1'b0, 6'd32, 1'b0, 1'b0,
            "TC3: Prescale=32 RX_CLK=3.686MHz  No Parity    0x55");

        // =========================================================
        // SECTION 2: All Three Frame Types (at Prescale=8)
        //   Req: Frame Type 1 (Even), Frame Type 2 (Odd), Frame Type 3 (None)
        // =========================================================
        $display("=========================================================");
        $display("  SECTION 2: All Frame Types at Prescale=8");
        $display("=========================================================");

        // TC4: Frame Type 1 — Even Parity (PAR_EN=1, PAR_TYP=0)
        send_uart_frame(8'hB7, 1'b1, 1'b0, 6'd8, 1'b0, 1'b0,
            "TC4: Frame Type 1 — Even Parity  0xB7");

        // TC5: Frame Type 2 — Odd Parity (PAR_EN=1, PAR_TYP=1)
        send_uart_frame(8'h4C, 1'b1, 1'b1, 6'd8, 1'b0, 1'b0,
            "TC5: Frame Type 2 — Odd Parity   0x4C");

        // TC6: Frame Type 3 — No Parity (PAR_EN=0)
        send_uart_frame(8'hE1, 1'b0, 1'b0, 6'd8, 1'b0, 1'b0,
            "TC6: Frame Type 3 — No Parity    0xE1");

        // =========================================================
        // SECTION 3: Error Detection
        //   Req: PAR_ERR=1 when parity mismatch
        //   Req: STP_ERR=1 when stop bit != 1
        //   Req: data_valid=0 when any error
        // =========================================================
        $display("=========================================================");
        $display("  SECTION 3: Error Detection");
        $display("=========================================================");

        // TC7: Parity Error — corrupted parity bit
        send_uart_frame(8'h3C, 1'b1, 1'b0, 6'd8, 1'b1, 1'b0,
            "TC7: Parity Error Injection 0x3C");

        // TC8: Stop Bit Error — stop bit = 0 instead of 1
        send_uart_frame(8'hC3, 1'b1, 1'b0, 6'd8, 1'b0, 1'b1,
            "TC8: Stop Bit Error Injection 0xC3");

        // =========================================================
        // SECTION 4: Consequent Frames (Back-to-Back, no gap)
        //   Req: UART_RX can accept consequent frames without any gap
        //   Waveform: IDLE -> Frame1(S,D,P,STP) -> Frame2(S,D,P,STP) -> IDLE
        // =========================================================
        $display("=========================================================");
        $display("  SECTION 4: Back-to-Back Consequent Frames");
        $display("=========================================================");

        send_uart_frame(8'hAA, 1'b1, 1'b0, 6'd8, 1'b0, 1'b0,
            "TC9:  Consequent Frame 1 — 0xAA");
        send_uart_frame(8'h55, 1'b1, 1'b0, 6'd8, 1'b0, 1'b0,
            "TC10: Consequent Frame 2 — 0x55");

        // =========================================================
        // SECTION 5: Reset Functionality
        //   Req: Registers cleared using asynchronous active-low reset
        // =========================================================
        $display("=========================================================");
        $display("  SECTION 5: Async Active-Low Reset");
        $display("=========================================================");
        $display("---------------------------------------------------------");
        $display("Running: TC11: Assert RST mid-frame, check all outputs 0");

        // Start a frame then assert RST mid-way
        Prescale = 6'd8;
        PAR_EN   = 1'b1;
        PAR_TYP  = 1'b0;
        clk_half_period = (8680.555 / 8) / 2.0;
        repeat(3) @(posedge CLK);
        RX_IN = 1'b0;  // Start bit
        repeat(4) @(posedge CLK); // Part-way through start bit
        RST = 1'b0;    // Assert reset asynchronously
        #3;
        // Check: all outputs should be 0/idle immediately
        if (P_DATA !== 8'h00 || data_valid !== 1'b0 ||
            Parity_Error !== 1'b0 || Stop_Error !== 1'b0)
            begin
                $display("  -> ERROR: Reset did not clear outputs! P_DATA=%h DV=%b", P_DATA, data_valid);
                err_count = err_count + 1;
            end
        else
            $display("  -> SUCCESS: Async RST cleared all outputs correctly");
        @(posedge CLK);
        RST   = 1'b1;
        RX_IN = 1'b1;
        repeat(10) @(posedge CLK);

        // TC12: Normal frame after reset
        send_uart_frame(8'hDE, 1'b1, 1'b0, 6'd8, 1'b0, 1'b0,
            "TC12: Normal frame after reset  0xDE");

        // =========================================================
        // Summary
        // =========================================================
        $display("=========================================================");
        if (err_count == 0)
            $display("  ALL 12 TEST CASES PASSED: 0 Errors.");
        else
            $display("  VERIFICATION FAILED: %0d Errors.", err_count);
        $display("=========================================================");

        $stop;
    end

endmodule
