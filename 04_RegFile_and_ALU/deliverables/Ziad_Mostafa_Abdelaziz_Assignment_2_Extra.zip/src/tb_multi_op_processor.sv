`timescale 1ns/1ns

module multi_op_processor_tb;

    // DUT inputs / outputs
    reg  [7:0] data_in;
    reg  [1:0] op_sel;
    wire [7:0] data_out;

    // Instantiate DUT
    multi_op_processor dut (
        .data_in(data_in),
        .op_sel(op_sel),
        .data_out(data_out)
    );

    // 1. Packed struct for 10-bit stimulus {data_in[7:0], op_sel[1:0]}
    typedef struct packed {
        bit [7:0] data_in;
        bit [1:0] op_sel;
    } stim_t;

    // Data structures
    stim_t stim_arr[];           // Dynamic array to store design stimuli
    bit [7:0] actual_q[$];       // Queue to collect actual outputs
    bit [7:0] expected_aa[int];  // Associative array to hold expected outputs (index = int)

    // Global counters
    int num_checks = 0;
    int num_errors = 0;

    // Helper task to read binary strings from file and push into ref queue
    task automatic read_bin_file(input string file_name, input int width, ref int q[$]);
        int fd;
        string line;
        int val;
        
        q.delete(); 
        fd = $fopen(file_name, "r");
        if (fd == 0) begin
            $fatal(1, "[FATAL] Failed to open file: %s", file_name);
        end
        
        while ($fscanf(fd, "%s\n", line) == 1) begin
            // Strip BOM or header characters if line length is larger than expected width
            if (line.len() > width) begin
                line = line.substr(line.len() - width, line.len() - 1);
            end

            if (line.len() != width) begin
                $fatal(1, "[FATAL] Length mismatch in file '%s'. Expected width: %0d, Got: %0d. Token: '%s'", 
                       file_name, width, line.len(), line);
            end
            
            val = 0;
            for (int i = 0; i < line.len(); i++) begin
                if (line[i] == "1") begin
                    val = (val << 1) | 1;
                end else if (line[i] == "0") begin
                    val = (val << 1);
                end else begin
                    $fatal(1, "[FATAL] Invalid binary character '%c' in file '%s'.", line[i], file_name);
                end
            end
            q.push_back(val);
        end
        $fclose(fd);
        $display("[INFO] Successfully read %0d items from file: %s", q.size(), file_name);
    endtask

    // Load inputs index and expected output into logic arrays
    task load_file_stimulus();
        int inputs_raw[$];
        int expected_raw[$];

        // Read using read_bin_file
        read_bin_file("E:/courses/Digital IC design Course/Digital Verification Course/system verilog assignments/assignment 2 extra/inputs.txt", 10, inputs_raw);
        read_bin_file("E:/courses/Digital IC design Course/Digital Verification Course/system verilog assignments/assignment 2 extra/expected_Out.txt", 8, expected_raw);

        if (inputs_raw.size() != expected_raw.size()) begin
            $fatal(1, "[FATAL] Size mismatch: inputs has %0d records, expected has %0d records", 
                   inputs_raw.size(), expected_raw.size());
        end

        // Allocate dynamic array of proper size
        stim_arr = new[inputs_raw.size()];

        // Parse and fill dynamic and associative arrays
        for (int i = 0; i < inputs_raw.size(); i++) begin
            stim_arr[i].data_in = inputs_raw[i][9:2];
            stim_arr[i].op_sel  = inputs_raw[i][1:0];
            expected_aa[i]      = expected_raw[i];
        end
        $display("[INFO] Loaded %0d stimuli records into dynamic array and expected outputs into associative array.", stim_arr.size());
    endtask

    // Drive stimulus from dynamic array to DUT ports
    task drive_stim();
        for (int i = 0; i < stim_arr.size(); i++) begin
            data_in = stim_arr[i].data_in;
            op_sel  = stim_arr[i].op_sel;
            #1; // Evaluation delay for combinational logic
            collect_output_data(data_out);
        end
        $display("[INFO] Finished driving all %0d stimulus vectors.", stim_arr.size());
    endtask

    // Collect design output and push to actual_q queue
    task collect_output_data(input bit [7:0] out_val);
        actual_q.push_back(out_val);
    endtask

    // Check results between actual queue and expected associative array
    task automatic check_results(ref bit [7:0] exp_aa[int], ref bit [7:0] act_q[$]);
        if (exp_aa.num() != act_q.size()) begin
            $display("[WARNING] Size mismatch: Expected size=%0d, Actual size=%0d", exp_aa.num(), act_q.size());
        end

        num_checks = 0;
        num_errors = 0;

        for (int i = 0; i < act_q.size(); i++) begin
            num_checks++;
            if (exp_aa.exists(i)) begin
                if (act_q[i] == exp_aa[i]) begin
                    $display("[CHECK][PASS] idx=%0d inputs={data_in:0x%2h, op_sel:2'b%0b} expected=0x%2h actual=0x%2h", 
                             i, stim_arr[i].data_in, stim_arr[i].op_sel, exp_aa[i], act_q[i]);
                end else begin
                    num_errors++;
                    $display("[CHECK][FAIL] idx=%0d inputs={data_in:0x%2h, op_sel:2'b%0b} expected=0x%2h actual=0x%2h", 
                             i, stim_arr[i].data_in, stim_arr[i].op_sel, exp_aa[i], act_q[i]);
                end
            end else begin
                num_errors++;
                $display("[CHECK][FAIL] idx=%0d is missing expected golden model value in associative array!", i);
            end
        end

        $display("\n=== SUMMARY: total_checks=%0d total_errors=%0d ===", num_checks, num_errors);
        if (num_errors == 0) begin
            $display("RESULT: ALL CHECKS PASSED\n");
        end else begin
            $display("RESULT: TEST FAILED WITH %0d ERRORS\n", num_errors);
        end
    endtask

    // Test Flow
    initial begin
        $display("=== Starting Assignment 2 Extra File-Based Verification ===");
        
        // 1. Load stimulus data from files
        load_file_stimulus();
        
        // 2. Drive stimulus
        drive_stim();
        
        // 3. Verify results
        check_results(expected_aa, actual_q);
        
        $finish;
    end

endmodule
