vlib work
vlog -sv -work work src/multi_op_processor.sv src/tb_multi_op_processor.sv
vsim -c work.multi_op_processor_tb
add wave *
run -all
