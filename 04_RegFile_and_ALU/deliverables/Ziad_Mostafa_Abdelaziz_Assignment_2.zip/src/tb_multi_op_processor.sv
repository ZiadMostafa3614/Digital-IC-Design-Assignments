`timescale 1ns/1ps

module multi_op_processor_tb;

  typedef struct packed {
    bit [7:0] data_in;
    bit [1:0] op_sel;
  } stim_t;

  stim_t          stim_arr[];       // dynamic array - stimulus storage
  bit [7:0]       actual_q[$];      // queue - collected DUT outputs
  bit [7:0]       expected_aa[int]; // associative array - expected values

  logic [7:0] data_in;
  logic [1:0] op_sel;
  logic [7:0] data_out;

  int num_checks;
  int num_errors;

  multi_op_processor dut (
    .data_in  (data_in),
    .op_sel   (op_sel),
    .data_out (data_out)
  );

  // Resizes stimulus array, clears queue + expected AA
  function void configure_stim_storage(int size);
    stim_arr = new[size];
    actual_q.delete();
    expected_aa.delete();
    $display("[CONFIG] Configured for %0d entries (queue & AA cleared)", size);
  endfunction

  // Randomizes data_in/op_sel for every stimulus entry
  task automatic generate_stimulus(ref stim_t arr[]);
    for (int i = 0; i < arr.size(); i++) begin
      arr[i].data_in = $urandom_range(0, 255);
      arr[i].op_sel  = $urandom_range(0, 3);
    end
    $display("[GEN] Generated %0d random stimulus items", arr.size());
  endtask

  // Drives each stimulus item to the DUT, then collects its output
  task automatic drive_stim();
    for (int i = 0; i < stim_arr.size(); i++) begin
      data_in = stim_arr[i].data_in;
      op_sel  = stim_arr[i].op_sel;
      #1;
      collect_output_data(data_out);
    end
    $display("[DRIVE] Drove %0d stimulus items", stim_arr.size());
  endtask

  // Computes expected output per stimulus item, stores in AA
  task automatic golden_model(ref bit [7:0] exp_aa[int]);
    bit [7:0] exp_val;
    for (int i = 0; i < stim_arr.size(); i++) begin
      case (stim_arr[i].op_sel)
        2'b00:   exp_val = stim_arr[i].data_in + 1;
        2'b01:   exp_val = stim_arr[i].data_in - 1;
        2'b10:   exp_val = ~stim_arr[i].data_in;
        2'b11:   exp_val = stim_arr[i].data_in << 1;
        default: exp_val = stim_arr[i].data_in;
      endcase
      exp_aa[i] = exp_val;
    end
    $display("[GOLDEN] Computed %0d expected values", exp_aa.num());
  endtask

  // Pushes one DUT output sample into the results queue
  task automatic collect_output_data(input bit [7:0] dut_out);
    actual_q.push_back(dut_out);
  endtask

  // Compares expected vs actual, prints pass/fail per item
  task automatic check_results(ref bit [7:0] exp_aa[int], ref bit [7:0] act_q[$]);
    if (act_q.size() != exp_aa.num())
      $display("[CHECK][WARNING] size mismatch: actual_q=%0d expected_aa=%0d",
                act_q.size(), exp_aa.num());

    for (int i = 0; i < act_q.size(); i++) begin
      num_checks++;
      if (act_q[i] === exp_aa[i]) begin
        $display("[CHECK][PASS] idx=%0d data_in=0x%0h op_sel=%0b expected=0x%0h actual=0x%0h",
                  i, stim_arr[i].data_in, stim_arr[i].op_sel, exp_aa[i], act_q[i]);
      end else begin
        num_errors++;
        $display("[CHECK][FAIL] idx=%0d data_in=0x%0h op_sel=%0b expected=0x%0h actual=0x%0h",
                  i, stim_arr[i].data_in, stim_arr[i].op_sel, exp_aa[i], act_q[i]);
      end
    end
    $display("[CHECK] --- %0d checks this pass ---", act_q.size());
  endtask

  // Shuffles stimulus order using built-in .shuffle()
  task automatic reconfigure_stim(ref stim_t arr[]);
    arr.shuffle();
    $display("[RECFG] Shuffled %0d items", arr.size());
  endtask

  initial begin
    num_checks = 0;
    num_errors = 0;

    $display("=== PASS 1: 100 stimulus items ===");
    configure_stim_storage(100);
    generate_stimulus(stim_arr);
    drive_stim();
    golden_model(expected_aa);
    check_results(expected_aa, actual_q);

    $display("=== PASS 2: reconfigure to 200 stimulus items ===");
    configure_stim_storage(200);
    generate_stimulus(stim_arr);
    drive_stim();
    golden_model(expected_aa);
    check_results(expected_aa, actual_q);

    $display("=== PASS 3: reorder 200 items, recheck ===");
    reconfigure_stim(stim_arr);
    actual_q.delete();
    golden_model(expected_aa);
    drive_stim();
    check_results(expected_aa, actual_q);

    $display("=== SUMMARY: total_checks=%0d total_errors=%0d ===", num_checks, num_errors);
    if (num_errors == 0)
      $display("RESULT: ALL CHECKS PASSED");
    else
      $display("RESULT: %0d CHECK(S) FAILED", num_errors);

    $finish;
  end

endmodule