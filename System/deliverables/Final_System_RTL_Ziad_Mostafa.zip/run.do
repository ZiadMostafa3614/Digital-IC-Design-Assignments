vlib work
vlog -f src_files.f
vsim -voptargs=+acc work.SYS_TOP_tb
add wave -position insertpoint sim:/SYS_TOP_tb/u_dut/*
run -all
